# BetaGrace vI Public Benchmark Prompt Release

Window: **2026-08-15 through 2026-08-25 UTC**, inclusive.

This package contains only user-authored image prompts and normalized UTC timestamps. It intentionally excludes session IDs, conversation IDs, message IDs, consent records, learning data, assistant responses, database dumps, API responses, URLs, secrets, and local paths.

`benchmark-prompts.csv` preserves every qualifying prompt row in chronological order. `benchmark-prompt-index.csv` collapses exact prompt repeats and records occurrence counts. The group labels are transparent keyword classifications, not database concept IDs.

This release supports chronology and prompt-iteration claims. It does **not** establish Pass/Fail decisions, image hashes, provider outcomes, or the reported attempt matrix because those fields are not present in the source database export.

The source export remains private and should not be published. Review the prompts for personal, proprietary, third-party, or copyrighted material before public distribution.

## Pre-Release Spot-Check — 2026-08-25

Spot-check performed prior to public distribution. Third-party copyrighted character names (Warner Bros. Looney Tunes: Bugs Bunny, Tasmanian Devil; Comedy Central: Cartman, South Park) were present in 7 early `concept-28-basketball` iterations (attempts 139–145, index entries 52–55). These were replaced with generic descriptors that are consistent with the same concept's own later clean iterations. All SHA-256 hashes for affected rows updated accordingly. No personal names, private details, or other copyrighted material were identified elsewhere in the dataset.
